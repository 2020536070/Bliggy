﻿public interface IJsonData
{
    string GetJson();
}