﻿//2079034130

public interface IMovement
{
    string Move(AAnimal animal);
} //IMovement

